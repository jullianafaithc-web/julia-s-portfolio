      const username = "jullianafaithc";
      const apiBase = `https://api.github.com/users/${username}`;
      const projectGrid = document.querySelector("#project-grid");
      const loadStatus = document.querySelector("#load-status");

      document.querySelector("#current-year").textContent = new Date().getFullYear();

      function setText(selector, value) {
        const element = document.querySelector(selector);
        if (value) element.textContent = value;
      }

      function createIcon(path) {
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", "0 0 24 24");
        svg.setAttribute("fill", "none");
        svg.setAttribute("stroke", "currentColor");
        svg.setAttribute("stroke-width", "1.7");
        svg.setAttribute("aria-hidden", "true");
        const shape = document.createElementNS("http://www.w3.org/2000/svg", "path");
        shape.setAttribute("d", path);
        svg.append(shape);
        return svg;
      }

      function setProfileLink(element, url) {
        element.href = url;
      }

      async function fetchGitHub(path) {
        const response = await fetch(`${apiBase}${path}`, {
          headers: { Accept: "application/vnd.github+json" },
        });
        if (!response.ok) {
          throw new Error(`GitHub returned ${response.status} for ${path || "profile"}`);
        }
        return response.json();
      }

      function renderProfile(profile) {
        setText("#profile-handle", `@${profile.login}`);
        setText("#repo-count", profile.public_repos);
        setText("#follower-count", profile.followers);
        setText("#following-count", profile.following);

        if (profile.bio) {
          setText("#hero-copy", profile.bio);
          setText("#about-copy", profile.bio);
        }

        if (profile.location) {
          setText("#profile-location", profile.location);
          document.querySelector("#location-row").hidden = false;
        }

        if (profile.company) {
          setText("#profile-company", profile.company);
          document.querySelector("#company-row").hidden = false;
        }

        if (profile.blog) {
          const website = document.querySelector("#profile-website");
          const websiteUrl = /^https?:\/\//i.test(profile.blog)
            ? profile.blog
            : `https://${profile.blog}`;
          website.href = websiteUrl;
          website.textContent = profile.blog;
          document.querySelector("#website-row").hidden = false;
        }

        for (const selector of ["#nav-github", "#hero-github", "#footer-github"]) {
          setProfileLink(document.querySelector(selector), profile.html_url);
        }
      }

      function makeProjectCard(repo, index) {
        const link = document.createElement("a");
        link.className = "project-card";
        link.href = repo.html_url;
        link.target = "_blank";
        link.rel = "noreferrer";
        link.setAttribute("aria-label", `View ${repo.name} on GitHub`);

        const top = document.createElement("div");
        top.className = "project-topline";
        const folder = document.createElement("span");
        folder.className = "project-folder";
        folder.textContent = "↗";
        folder.setAttribute("aria-hidden", "true");
        const stats = document.createElement("span");
        stats.className = "project-stats";

        const stars = document.createElement("span");
        stars.className = "project-stat";
        stars.append(createIcon("m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"));
        stars.append(document.createTextNode(repo.stargazers_count.toLocaleString()));
        stats.append(stars);

        if (repo.forks_count > 0) {
          const forks = document.createElement("span");
          forks.className = "project-stat";
          forks.append(createIcon("M7 7v10m0-10a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm0 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm10-5v5a2 2 0 1 1-2 2m2-7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"));
          forks.append(document.createTextNode(repo.forks_count.toLocaleString()));
          stats.append(forks);
        }

        top.append(folder, stats);

        const title = document.createElement("h3");
        title.className = "project-title";
        title.textContent = repo.name;

        const description = document.createElement("p");
        description.className = "project-description";
        description.textContent = repo.description || "A project in progress. Explore the repository to learn more.";

        const bottom = document.createElement("div");
        bottom.className = "project-bottom";
        const language = document.createElement("span");
        language.className = "project-language";
        if (repo.language) {
          const dot = document.createElement("span");
          dot.className = "language-dot";
          dot.setAttribute("aria-hidden", "true");
          language.append(dot, document.createTextNode(repo.language));
        } else {
          language.textContent = "Open source";
        }

        const arrow = document.createElement("span");
        arrow.className = "project-arrow";
        arrow.textContent = "↗";
        arrow.setAttribute("aria-hidden", "true");
        bottom.append(language, arrow);
        link.append(top, title, description, bottom);
        link.style.setProperty("--project-index", index);
        return link;
      }

      function renderRepositories(repositories) {
        const publicRepos = repositories
          .filter((repo) => !repo.fork && !repo.archived)
          .sort((a, b) => b.stargazers_count - a.stargazers_count || new Date(b.pushed_at) - new Date(a.pushed_at))
          .slice(0, 6);

        projectGrid.replaceChildren();
        projectGrid.setAttribute("aria-busy", "false");

        if (publicRepos.length === 0) {
          const empty = document.createElement("p");
          empty.className = "load-message";
          empty.textContent = "No public projects to show just yet. Check back soon.";
          projectGrid.append(empty);
          loadStatus.textContent = "No public projects were found.";
        } else {
          publicRepos.forEach((repo, index) => projectGrid.append(makeProjectCard(repo, index)));
          loadStatus.textContent = `${publicRepos.length} GitHub projects loaded.`;
        }

      }

      function showProjectError() {
        projectGrid.setAttribute("aria-busy", "false");
        const message = document.createElement("p");
        message.className = "load-message";
        message.textContent = "Projects couldn’t load right now. You can still browse all public repositories on GitHub.";
        const link = document.createElement("a");
        link.href = `https://github.com/${username}?tab=repositories`;
        link.target = "_blank";
        link.rel = "noreferrer";
        link.textContent = " View repositories ↗";
        message.append(link);
        projectGrid.replaceChildren(message);
        loadStatus.textContent = "Projects could not be loaded from GitHub.";
      }

      async function loadPortfolio() {
        const [profileResult, repositoriesResult] = await Promise.allSettled([
          fetchGitHub(""),
          fetchGitHub("/repos?per_page=100&sort=updated"),
        ]);

        if (profileResult.status === "fulfilled") {
          renderProfile(profileResult.value);
        } else {
          console.error("Unable to load GitHub profile:", profileResult.reason);
        }

        if (repositoriesResult.status === "fulfilled") {
          renderRepositories(repositoriesResult.value);
        } else {
          console.error("Unable to load GitHub repositories:", repositoriesResult.reason);
          showProjectError();
        }
      }

      /* Custom portfolio content is defined in the static markup above. */
    
